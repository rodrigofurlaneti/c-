﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebCru.Models;

namespace WebCru.Controllers
{
    public class DALController : Controller
    {
        private DALContext db = new DALContext();

        // GET: /DAL/
        public ActionResult Index()
        {
            return View(db.AgendaMODs.ToList());
        }

        // GET: /DAL/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AgendaMOD agendamod = db.AgendaMODs.Find(id);
            if (agendamod == null)
            {
                return HttpNotFound();
            }
            return View(agendamod);
        }

        // GET: /DAL/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /DAL/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="Id,Nome,Telefone,Comentario")] AgendaMOD agendamod)
        {
            if (ModelState.IsValid)
            {
                db.AgendaMODs.Add(agendamod);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(agendamod);
        }

        // GET: /DAL/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AgendaMOD agendamod = db.AgendaMODs.Find(id);
            if (agendamod == null)
            {
                return HttpNotFound();
            }
            return View(agendamod);
        }

        // POST: /DAL/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Id,Nome,Telefone,Comentario")] AgendaMOD agendamod)
        {
            if (ModelState.IsValid)
            {
                db.Entry(agendamod).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(agendamod);
        }

        // GET: /DAL/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AgendaMOD agendamod = db.AgendaMODs.Find(id);
            if (agendamod == null)
            {
                return HttpNotFound();
            }
            return View(agendamod);
        }

        // POST: /DAL/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            AgendaMOD agendamod = db.AgendaMODs.Find(id);
            db.AgendaMODs.Remove(agendamod);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
