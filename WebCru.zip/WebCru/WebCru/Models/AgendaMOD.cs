﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebCru.Models
{
    public class AgendaMOD
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Entre com o nome")]
        public string Nome { get; set; }
        
        [Required(ErrorMessage = "Entre com o número do telefone")]
        public string Telefone { get; set; }
        
        [Required(ErrorMessage = "Entre com a descrição")]
        [DataType(DataType.MultilineText)]
        [DisplayName("Comentário")]
        public string Comentario { get; set; }

    }
}