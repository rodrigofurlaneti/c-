﻿using System;

namespace LogicaDeProgramacao.Lista2
{
    public class CalculadoraDeMediaSimples : IExercicio
    {
        public bool VerificarResposta()
        {
            return
                  Validar.SaoIguais(2, () => Rodar(2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2))
               && Validar.SaoIguais(3, () => Rodar(10, 3, 0, -1))
               ;
        }

        public int Rodar(params int[] numeros)
        {
            int quant = numeros.Length;
            int acum = 0;
            for (int i = 0; i < quant; i++)
            {
                acum += numeros[i];
            }
            int result = acum / quant;
            return result;
        }
    }
}
